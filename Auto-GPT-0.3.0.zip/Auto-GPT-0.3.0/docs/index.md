# Auto-GPT

Welcome to Auto-GPT.  Please follow the [Installation](/setup/) guide to get started.

It is recommended to use a virtual machine for tasks that require high security measures to prevent any potential harm to the main computer's system and data.
